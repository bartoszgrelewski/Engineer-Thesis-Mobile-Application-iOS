//
//  ScannedModel.swift
//  LiDAR_APP
//
//  Created by Bartosz Grelewski on 25/11/2023.
//

import Foundation

struct ScannedModel{
    let filePath: String
    let creationDate: String
}

